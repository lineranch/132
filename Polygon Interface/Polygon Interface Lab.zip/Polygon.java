
public interface Polygon {

	
	public void perimeter(float side_length, float side_width);
	
	
	public void area(float side_length, float side_width);
	
}

